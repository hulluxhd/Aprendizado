package CheckpointPokemon;

public class Wartortle extends Pokemon {

    // instância de um pokémon (classe filha)

    public Wartortle(int numeroPokedex, String nome, String apelido, int LV, int ATK, int DEF, int SPD, Elemento tipo) {
        super(numeroPokedex, nome, apelido, LV, ATK, DEF, SPD, tipo);
    }
}
