package CheckpointPokemon;

public class Bulbasaur extends Pokemon {

    // instância de um pokémon (classe filha)

    public Bulbasaur(int numeroPokedex, String nome, String apelido, int LV, int ATK, int DEF, int SPD, Elemento tipo) {
        super(numeroPokedex, nome, apelido, LV, ATK, DEF, SPD, tipo);
    }
}
