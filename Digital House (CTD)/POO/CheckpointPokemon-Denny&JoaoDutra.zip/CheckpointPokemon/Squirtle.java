package CheckpointPokemon;

public class Squirtle extends Pokemon {

    // instância de um pokémon (classe filha)

    public Squirtle(int numeroPokedex, String nome, String apelido, int LV, int ATK, int DEF, int SPD, Elemento tipo) {
        super(numeroPokedex, nome, apelido, LV, ATK, DEF, SPD, tipo);
    }

}
