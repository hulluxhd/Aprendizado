package CheckpointPokemon;

import java.util.ArrayList;

public class Charmander extends Pokemon {
    // instância de um pokémon (classe filha)
    public Charmander(int numeroPokedex, String nome, String apelido, int LV, int ATK, int DEF, int SPD, Elemento tipo) {
        super(numeroPokedex, nome, apelido, LV, ATK, DEF, SPD, tipo);
    }
}
